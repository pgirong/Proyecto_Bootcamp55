package com.nttdata.Proyecto01Giron.business;

import com.nttdata.Proyecto01Giron.model.entity.Cliente;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public Cliente getClienteEntity(com.nttdata.Proyecto01Giron.model.Cliente request){
        Cliente entity = new Cliente();
        entity.setDni(request.getDni());
        entity.setApellido(request.getApellido());
        entity.setEmail(request.getEmail());
        entity.setNombre(request.getNombre());
        return entity;

    }

    public com.nttdata.Proyecto01Giron.model.Cliente getClienteResponse(Cliente entity){
        com.nttdata.Proyecto01Giron.model.Cliente response = new com.nttdata.Proyecto01Giron.model.Cliente();
        response.setDni(entity.getDni());
        response.setApellido(entity.getApellido());
        response.setEmail(entity.getEmail());
        response.setNombre(entity.getNombre());
        return response;

    }





}
