package com.nttdata.Proyecto01Cuentas.business;

import com.nttdata.Proyecto01Cuentas.repository.CuentaRepository;
import com.nttdata.Proyecto01Giron.model.CuentaResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentaServiceImp implements CuentaService{

    @Autowired
    CuentaRepository cuentaRepository;

    @Autowired
    CuentaMapper cuentaMapper;

    @Override
    public List<CuentaResponse> listarCuenta(){
        return cuentaRepository.findAll().stream()
                .map(m-> cuentaMapper.getCuentaResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public CuentaResponse crearCuenta(CuentaResponse cuentaRequest){
        return cuentaMapper
                .getCuentaResponse(cuentaRepository.
                        save(cuentaMapper.getCuentaEntity(cuentaRequest)));
    }


}
