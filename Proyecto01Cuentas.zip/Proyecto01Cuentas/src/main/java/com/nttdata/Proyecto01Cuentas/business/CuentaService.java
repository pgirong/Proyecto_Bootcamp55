package com.nttdata.Proyecto01Cuentas.business;

import com.nttdata.Proyecto01Giron.model.CuentaResponse;

import java.util.List;

public interface CuentaService {
    public List<CuentaResponse> listarCuenta();
    public CuentaResponse crearCuenta(CuentaResponse cuentaRequest);

}
