package com.nttdata.Proyecto01Cuentas.business;

import com.nttdata.Proyecto01Cuentas.model.entity.Cuenta;
import com.nttdata.Proyecto01Giron.model.CuentaResponse;
import org.springframework.stereotype.Component;

@Component
public class CuentaMapper {

     public Cuenta getCuentaEntity(CuentaResponse request){
         Cuenta entity = new Cuenta();
         entity.setNumero(request.getNumero());
         entity.setTipo(request.getTipo());

         return entity;

     }

     public CuentaResponse getCuentaResponse(Cuenta entity){
         CuentaResponse response = new CuentaResponse();
         response.setNumero(entity.getNumero());
         response.setTipo(entity.getTipo());

         return response;
     }



}
